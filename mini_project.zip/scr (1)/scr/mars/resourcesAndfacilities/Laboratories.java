
package mars.resourcesAndfacilities;

public class Laboratories extends Facilities {

    private int currentResearchers;
    private int activeExperiments;
    private final int maxExperiments;
    private final String labType;


    // ---------------- Constructor ----------------

    public Laboratories(String name, String location,int capacity, boolean operational,int currentResearchers,
        int activeExperiments,int maxExperiments, String labType) {

        super(name, location, capacity, operational);
        if (currentResearchers < 0
                || currentResearchers > capacity) {
            throw new IllegalArgumentException(
                    "Researchers must be between zero and capacity."
            );
        }
        if (maxExperiments <= 0) {
            throw new IllegalArgumentException(
                    "Maximum experiments must be positive."
            );
        }
        if (activeExperiments < 0
                || activeExperiments > maxExperiments) {
            throw new IllegalArgumentException(
                    "Active experiments must be between zero and maximum."
            );
        }
        if (labType == null || labType.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Laboratory type cannot be empty."
            );
        }
        this.currentResearchers = currentResearchers;
        this.activeExperiments = activeExperiments;
        this.maxExperiments = maxExperiments;
        this.labType = labType.trim();

        checkBatteryPower();
    }


    // ---------------- Getters ----------------

    public int getCurrentResearchers() {
        return currentResearchers;
    }
    public int getActiveExperiments() {
        return activeExperiments;
    }
    public int getMaxExperiments() {
        return maxExperiments;
    }
    public String getLabType() {
        return labType;
    }


    // ---------------- Researchers Management ----------------

    public int getAvailableSpaces() {
        return getCapacity() - currentResearchers;
    }
    public boolean addResearcher() {

        if (!isOperational() || currentResearchers >= getCapacity()) {
            return false;
        }
        currentResearchers++;
        return true;
    }
    public boolean removeResearcher() {

        if (currentResearchers == 0) {
            return false;
        }
        currentResearchers--;
        return true;
    }


    // ---------------- Experiments Management ----------------

    public int getAvailableExperiments() {
        return maxExperiments - activeExperiments;
    }

    public boolean startExperiment() {

        if (!isOperational()
                || currentResearchers == 0
                || activeExperiments >= maxExperiments) {
            return false;
        }

        activeExperiments++;
        return true;
    }
    public boolean endExperiment() {

        if (activeExperiments == 0) {
            return false;
        }
        activeExperiments--;
        return true;
    }


    // ---------------- Battery Power Management ----------------

    private void checkBatteryPower() {

        Resource batteryPower = getResource("Battery Power");
        if (batteryPower.getQuantity() == 0) {
            setOperational(false);
        }
    }

    public boolean consumeBatteryPower(double amount) {

        Resource batteryPower = getResource("Battery Power");
        boolean consumed = batteryPower.consume(amount);
        checkBatteryPower();
        return consumed;
    }

    public boolean addBatteryPower(double amount) {

        Resource batteryPower = getResource("Battery Power");
        boolean added = batteryPower.addQuantity(amount);
        checkBatteryPower();
        return added;
    }
}