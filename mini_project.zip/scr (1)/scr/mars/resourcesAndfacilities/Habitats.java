
package mars.resourcesAndfacilities;
public class Habitats extends Facilities {

    private int currentOccupants;
    private double temperature = 25.0;


    // ---------------- Constructor ----------------

    public Habitats(String name, String location,
                   int capacity, boolean operational,
                   int currentOccupants) {

        super(name, location, capacity, operational);

        if (currentOccupants < 0
                || currentOccupants > capacity) {
            throw new IllegalArgumentException(
                    "Current occupants must be between zero and capacity."
            );
        }

        this.currentOccupants = currentOccupants;

        checkOxogen();
    }


    // ---------------- Getters ----------------

    public int getCurrentOccupants() {
        return currentOccupants;
    }

    public double getTemperature() {
        return temperature;
    }


    // ---------------- Temperature ----------------

    public boolean setTemperature(double temperature) {

        if (!Double.isFinite(temperature)
                || temperature < 20.0
                || temperature > 40.0) {
            return false;
        }

        this.temperature = temperature;
        return true;
    }


    // ---------------- Occupancy Management ----------------

    public int getAvailableSpaces() {
        return getCapacity() - currentOccupants;
    }

    public boolean addOccupant() {

        if (!isOperational() || isFull()) {
            return false;
        }

        currentOccupants++;
        return true;
    }

    public boolean removeOccupant() {

        if (currentOccupants == 0) {
            return false;
        }

        currentOccupants--;
        return true;
    }

    public boolean isFull() {
        return currentOccupants == getCapacity();
    }


    // ---------------- Oxygen Management ----------------

    private void checkOxogen() {

        Resource oxogen = getResource("oxogen");

        if (oxogen.getQuantity() == 0) {
            setOperational(false);
        }
    }


    public boolean consumeOxogen(double amount) {

        Resource oxogen = getResource("oxogen");

        boolean consumed = oxogen.consume(amount);

        checkOxogen();

        return consumed;
    }


    public boolean addOxogen(double amount) {

        Resource oxogen = getResource("oxogen");

        boolean added = oxogen.addQuantity(amount);

        checkOxogen();

        return added;
    }
}