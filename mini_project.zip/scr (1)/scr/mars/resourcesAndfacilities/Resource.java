
package mars.resourcesAndfacilities;

public class Resource {

    private final String resourceType;
    private final String unit;
    private final double capacity;
    private double quantity;


    //------------ Constructor

    public Resource(String resourceType, double quantity,
                    double capacity, String unit) {

        if (resourceType == null || resourceType.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Resource type cannot be empty."
            );
        }

        if (unit == null || unit.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Unit cannot be empty."
            );
        }

        if (!Double.isFinite(capacity) || capacity <= 0) {
            throw new IllegalArgumentException(
                    "Capacity must be finite and positive."
            );
        }

        if (!Double.isFinite(quantity)
                || quantity < 0
                || quantity > capacity) {
            throw new IllegalArgumentException(
                    "Quantity must be between zero and capacity."
            );
        }

        this.resourceType = resourceType.trim();
        this.unit = unit.trim();
        this.capacity = capacity;
        this.quantity = quantity;
    }


    // --------------Getters

    public String getResourceType() {
        return resourceType;
    }

    public String getUnit() {
        return unit;
    }

    public double getQuantity() {
        return quantity;
    }

    public double getCapacity() {
        return capacity;
    }

    public double getAvailableCapacity() {
        return capacity - quantity;
    }


    //-------------- Add quantity

    public boolean addQuantity(double amount) {

        if (!Double.isFinite(amount) || amount <= 0) {
            return false;
        }
        if (amount > getAvailableCapacity()) {
            return false;
        }
        
        quantity += amount;
        return true;
    }


    // --------------Consume quantity

    public boolean consume(double amount) {

        if (!Double.isFinite(amount) || amount <= 0) {
            return false;
        }

        if (amount > quantity) {
            return false;
        }

        quantity -= amount;

        return true;
    }

    // --------------
    
    public void deduceLoss(double amount){
    if(amount > quantity){
     quantity=0;
    }
     quantity -= amount;}
    
    
    public void deduceLoss(){
   quantity=0;}
    
    
    
    
    
    
    
    
    
    //------------- Display resource information

    @Override
    public String toString() {
        return resourceType + ": "
                + quantity + "/" + capacity + " " + unit;
    }
}