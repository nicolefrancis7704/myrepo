
package mars.resourcesAndfacilities;


public class Storage extends Facilities {

    //------------ Constructor------------

    public Storage(String name, String location,int capacity, boolean operational) {
        super(name, location, capacity, operational);
        checkResources();
    }


    //------------ Check Resources----------

    private void checkResources() {
        boolean allEmpty = true;
        for (Resource resource : resources) {
            if (resource.getQuantity() > 0) {
                allEmpty = false;
                break;
            }
        }
        if (allEmpty) {
            setOperational(false);
        } else {
            setOperational(true);
        }
    }


    //------------ Add Resource Quantity-------

    public boolean addResource(String resourceType, double amount) {

        Resource resource = getResource(resourceType);
        if (resource == null) {
            return false;
        }
        boolean added = resource.addQuantity(amount);
        if (added) {
            checkResources();
        }
        return added;
    }


    //------------ Consume Resource Quantity------

    public boolean consumeResource(String resourceType, double amount) {
        if (!isOperational()) {
            return false;
        }
        Resource resource = getResource(resourceType);
        if (resource == null) {
            return false;
        }
        boolean consumed = resource.consume(amount);
        if (consumed) {
            checkResources();
        }
        return consumed;
    }
}