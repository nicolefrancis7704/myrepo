
package mars.resourcesAndfacilities;


public class PowerStation extends Facilities {

    //------------ Constructor---------------

    public PowerStation(String name, String location, int capacity, boolean operational) {
        super(name, location, capacity, operational);
        checkResources();
    }


    //------------ Check Resources-------------

    private void checkResources() {

        Resource fuel = getResource("Fuel");
        Resource batteryPower = getResource("Battery Power");

        if (fuel == null || batteryPower == null) {
            setOperational(false);
            return;
        }

        if (fuel.getQuantity() == 0
                && batteryPower.getQuantity() == 0) {

            setOperational(false);

        } else {
            setOperational(true);
        }
    }


    //------------ Add Resource Quantity

    public boolean addResource(String resourceType, double amount) {
        Resource resource = getResource(resourceType);
        if (resource == null) {
            return false;
        }
        boolean added = resource.addQuantity(amount);

        if (added) {
            checkResources();
        }
        return added;
    }


    //------------ Consume Resource Quantity--------------

    public boolean consumeResource(String resourceType, double amount) {
        if (!isOperational()) {
            return false;
        }
        if (!resourceType.equals("Fuel")
                && !resourceType.equals("Battery Power")) {
            return false;
        }
        Resource resource = getResource(resourceType);

        if (resource == null) {
            return false;
        }
        boolean consumed = resource.consume(amount);

        if (consumed) {
            checkResources();
        }
        return consumed;
    }
}