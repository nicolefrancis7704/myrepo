
package mars.resourcesAndfacilities;
import java.util.Arrays;


public class CommunicationStation extends Facilities {

    private String[] equipment;


    //------------ Constructor

    public CommunicationStation(String name, String location, int capacity, boolean operational, String[] equipment) {
        super(name, location, capacity, operational);
        this.equipment = equipment;
        checkResources();
    }


    //------------ Check Resources and Equipment

    private void checkResources() {
        Resource batteryPower = getResource("Battery Power");
        if (batteryPower == null
                || batteryPower.getQuantity() == 0
                || equipment == null
                || equipment.length == 0) {

            setOperational(false);
        } else {
            setOperational(true);
        }
    }


    //------------ Get Equipment

    public String[] getEquipment() {
        return Arrays.copyOf(equipment, equipment.length);
    }


    //------------ Add Equipment

    public boolean addEquipment(String equipmentName) {
        if (equipmentName == null
                || equipmentName.trim().isEmpty()) {
            return false;
        }
        if (containsEquipment(equipmentName)) {
            return false;
        }
        equipment = Arrays.copyOf(
                equipment, equipment.length + 1
        );
        equipment[equipment.length - 1] = equipmentName.trim();
        checkResources();
        return true;
    }


    //------------ Remove Equipment

    public boolean removeEquipment(String equipmentName) {
        if (equipmentName == null
                || equipmentName.trim().isEmpty()) {
            return false;
        }
        int index = -1;
        for (int i = 0; i < equipment.length; i++) {
            if (equipment[i].equalsIgnoreCase(equipmentName.trim())) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            return false;
        }
        String[] newEquipment = new String[equipment.length - 1];
        for (int i = 0, j = 0; i < equipment.length; i++) {
            if (i != index) {
                newEquipment[j++] = equipment[i];
            }
        }
        equipment = newEquipment;
        checkResources();
        return true;
    }


    //------------ Contains Equipment

    public boolean containsEquipment(String equipmentName) {
        if (equipmentName == null
                || equipmentName.trim().isEmpty()) {
            return false;
        }
        for (String equipment1 : equipment) {
            if (equipment1.equalsIgnoreCase(equipmentName.trim())) {
                return true;
            }
        }
        return false;
    }
}
