
package mars.resourcesAndfacilities;

public abstract class Facilities {

    public  final String name;
    public final String location;
    public final int capacity;       
    public boolean operational;
    

    public  Resource[] resources = {
        new Resource("Oxygen", 3000, 5000, "litre"),
        new Resource("Water", 7000, 10000, "litre"),
        new Resource("Food", 10000, 50000, "kcal"),
        new Resource("Fuel", 3000, 5000, "litre"),
        new Resource("Battery Power", 4000, 5000, "kWh"),
        new Resource("Medical Supplies", 300, 3000, "unit"),
        new Resource("Spare Parts", 300, 500, "unit")
    };


  //---------------constrctor-----------------------
    
    public Facilities(String name, String location, int capacity, boolean operational) {

        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Facility name cannot be empty."
            );
        }

        if (location == null || location.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Facility location cannot be empty."
            );
        }

        if (capacity <= 0) {
            throw new IllegalArgumentException(
                    "Facility capacity must be positive."
            );
        }

        this.name = name.trim();
        this.location = location.trim();
        this.capacity = capacity;
        this.operational = operational;
    }


    //------------------- Getters----------------------
    
    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isOperational() {
        return operational;
    }

    public void setOperational(boolean operational) {
        this.operational = operational;
    }
    
    public boolean isOperational(boolean operational) {
        return operational ==true;
    }


    //-----------Resource management---------------------
    
    public Resource getResource(String resourceType) {

        if (resourceType == null
                || resourceType.trim().isEmpty()) {
            return null;
        }

        for (Resource resource : resources) {
            if (resource.getResourceType()
                    .equalsIgnoreCase(resourceType.trim())) {
                return resource;
            }
        }

        return null;
    }

    
    
    
    
}