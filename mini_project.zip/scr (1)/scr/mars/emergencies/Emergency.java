package mars.emergencies;
import java.util.List;
import mars.agent.Agent;

abstract public class Emergency {
 private String emergencyType;
 private String location;    
 private String status;
 //private emergencyStatus status = emergencyStatus.PENDING;
 public Emergency(String emergencyType, String location,String status) {
    this.emergencyType = emergencyType;
    this.location = location;
    this.status=status;
}

 public String getEmergencyType() {
    return emergencyType;
}

 public String getLocation() {
    return location;
 }



 public String getStatus() {
     return status; }
  
     public void setStatus(String status) {
     this.status = status;
  }
void freeAgents(List <Agent>agents){
for (Agent agent : agents) {
   agent.setAvailable(true);
}
}
 
public abstract List<Agent> callingAgents(List<Agent> agents);
 //public abstract void handlingEmergency(List<Agent>agents);
 public abstract void resolvingEmergency(List<Agent> availableResponders);
//  public abstract void isResolved();

 }