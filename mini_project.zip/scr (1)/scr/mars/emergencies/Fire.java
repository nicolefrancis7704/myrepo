package mars.emergencies;
import java.util.List;
import java.util.ArrayList;
import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Resource;
import mars.agent.Agent;

public class Fire extends Emergency {
    Facilities facility;
    List <Resource> resources;
    Resource oxygen;
    private double consumedOxygenAmount;
    public Fire(String emergencyType, String location, String status,Facilities facility,double consumedOxygenAmount) {
        super(emergencyType, location,"unresolved");
        this.facility = facility;
        oxygen = this.facility.getResource("Oxygen");
        if (!Double.isFinite(consumedOxygenAmount) || consumedOxygenAmount <= 0)
           throw new IllegalArgumentException("insuffesient amount");
           else
           this.consumedOxygenAmount=consumedOxygenAmount;
           facility.setOperational(false); }
 
 
  void damagedResources(){
   for (Resource resource : facility.resources) {
    if(resource.getResourceType().equalsIgnoreCase("spare parts")||resource.getResourceType().equalsIgnoreCase("Medical Supplies")||
    resource.getResourceType().equalsIgnoreCase("Battery Power")||resource.getResourceType().equalsIgnoreCase("food")||
    resource.getResourceType().equalsIgnoreCase("water")){
        resource.deduceLoss();
    }    
   }
 }    
 
 
 @Override 
    public List<Agent> callingAgents(List<Agent> agents){
      int h=4;int r=2;                                   //at most 4 humans and 2 robots
      List<Agent>avaiableResponders=new ArrayList<>();  //at least 2 humans and 2 robots
      
        for (Agent responder : agents) {
        if(responder.canHandleEmergency(getEmergencyType())&&responder.isAvailable()){  //waiting the missions part
          
          if(responder.isHuman() && h>0) 
          {
            avaiableResponders.add(responder);
            h--;}
          if(!responder.isHuman() && r>0)
            {
             avaiableResponders.add(responder); 
             r--;
            }
        }
      }
      if(r!=0 || h>2){
        return new ArrayList<>();
      }
      
      return avaiableResponders;
    }

@Override 
    public void resolvingEmergency(List<Agent> agents){
    List<Agent> availableresponders =callingAgents(agents);
   if(!availableresponders.isEmpty()){
     for(Agent responder :availableresponders){
      responder.setAvailable(false);                //wanna change it to be more protected
      }
    damagedResources();
    oxygen.consume(consumedOxygenAmount);
    this.setStatus("resolved");
    for(Agent responder : availableresponders){
      responder.setAvailable(true); }
    System.out.println("Fire is put out"); } 
    else{
      oxygen.consume(consumedOxygenAmount*2); 
      setStatus("unresolved");
      throw new IllegalArgumentException("No enough available agents");
    }     
  
  }








        }
