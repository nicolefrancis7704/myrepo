package mars.emergencies;
public enum emergencyStatus { PENDING, RESOLVED, UNRESOLVED }

