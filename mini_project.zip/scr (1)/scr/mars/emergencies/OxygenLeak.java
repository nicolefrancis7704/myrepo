package mars.emergencies;
import java.util.List;
import java.util.ArrayList;
import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Resource;
import mars.agent.Agent;

public class OxygenLeak extends Emergency {
   Facilities facility;
   Resource resource;
   private double leakedAmount;
   public OxygenLeak(String emergencyType, String location, String status,Facilities facility,double leakedAmount) {
           super(emergencyType, location, "unresolved");
           this.facility = facility;
           resource = this.facility.getResource("Oxygen");
          
           if (!Double.isFinite(leakedAmount) || leakedAmount <= 0)
           throw new IllegalArgumentException("insuffesient amount");
           else
           this.leakedAmount=leakedAmount;
           facility.setOperational(false); 
          }
     
    
    
    @Override 
    public List<Agent> callingAgents(List<Agent> agents){
      int h=2;int r=1;                                //at most 2 humans and 1 robots
      List<Agent>avaiableResponders=new ArrayList<>(); //at least 1 human and 1 robot
      
        for (Agent responder : agents) {
        if(responder.canHandleEmergency(getEmergencyType())&&responder.isAvailable()){  //waiting the missions part
          
          if(responder.isHuman() && h>0) 
          {
            avaiableResponders.add(responder);
            h--;}
          if(!responder.isHuman() && r>0)
            {
             avaiableResponders.add(responder); 
             r--;
            }
        }
      }
      if(r!=0 || h>1){
        //System.out.println("No enough available agents");
        return new ArrayList<>();
      }
      // else{
      // for(Agent responder : avaiableResponders){
      // responder.setAvailable(false);                //wanna change it to be more protected
      // }
      return avaiableResponders;
    }
  
   
   
    @Override 
    public void resolvingEmergency(List<Agent> Responders){
    List<Agent> availableResponders =callingAgents(Responders);
   if(!availableResponders.isEmpty()){
     for(Agent responder : availableResponders){
      responder.setAvailable(false);                //wanna change it to be more protected
      }
    resource.deduceLoss(leakedAmount);
    facility.setOperational(true);
    setStatus("resolved");
    for(Agent responder : availableResponders){
      responder.setAvailable(true); }
    System.out.println("Oxygen leak resolved"); } 
    else{
      setStatus("unresolved");
      resource.deduceLoss(leakedAmount*2);
      throw new IllegalArgumentException("No enough available agents");
    }     
  
  }
      
  //  @Override 
  //  public void handlingEmergency(List<Agent>agents){
  //  List<Agent> responders =callingAgents(agents);
  //  resolvingEmergency(responders);

  }
    




