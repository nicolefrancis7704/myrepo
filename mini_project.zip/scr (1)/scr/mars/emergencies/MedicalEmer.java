package mars.emergencies;
import java.util.ArrayList;
import java.util.List;
import mars.agent.Agent;
import mars.agent.CrewMember;
import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Resource;

public class MedicalEmer extends Emergency {
  CrewMember patient;
  Facilities facility;
  int suppliesAmountNeeded;
  Resource medicl_equip;
  public MedicalEmer(String emergencyType, String location, String status, CrewMember patient,Facilities facility,int suppliesAmountNeeded) {
    super(emergencyType, location, "unresolved");
    this.patient = patient;
    if (patient.getFatigue()<=100) {
        throw new IllegalArgumentException("the crew member is not a patient");}
        this.facility=facility;
        medicl_equip = this.facility.getResource("Medical Supplies");
    if (suppliesAmountNeeded<=0) {
        throw new IllegalArgumentException("Insufficient amount");
    }
    this.suppliesAmountNeeded=suppliesAmountNeeded;
    
    
    }
 
  @Override 
    public List<Agent> callingAgents(List<Agent> agents){                              //at most 2 doctors
        int maxDoctor=2;
        List<Agent>availableDoctors=new ArrayList<>(); 
        for (Agent responder : agents) {
        if(responder.canHandleEmergency(getEmergencyType())&&responder.isAvailable()){  //waiting the missions part
          if (maxDoctor>0){
           availableDoctors.add(responder);
           maxDoctor--;
          }
        }
      }
       if(maxDoctor==2){
        System.out.println("NO enough doctors");
        return new ArrayList<>();
       }
    return availableDoctors;
}

    @Override 
    public void resolvingEmergency(List<Agent> agents){
    List<Agent> responders =callingAgents(agents);
    if(!responders.isEmpty()){
     for(Agent responder : responders){
      responder.setAvailable(false);                //wanna change it to be more protected
      }
    }
    else{
        throw new IllegalArgumentException("cannot be resolved NO enough doctors");}
  
    if(!facility.isOperational())
        {   freeAgents(responders);  
          throw new IllegalArgumentException("cannot be resolved the relevant facility isnot operating");}  
    if(medicl_equip.getQuantity()<suppliesAmountNeeded)
        {   freeAgents(responders);
            throw new IllegalArgumentException("cannot be resolved no enough medical supplies");}
    patient.decreaseFatigue(50);
    patient.increaseHealth(50);
    medicl_equip.consume(suppliesAmountNeeded);
    setStatus("resolved");
    freeAgents(responders);}
}
