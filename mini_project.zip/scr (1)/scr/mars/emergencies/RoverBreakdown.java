package mars.emergencies;
import java.util.List;
import java.util.ArrayList;
import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Resource;
import mars.resourcesAndfacilities.Storage;
import mars.agent.Agent;
import mars.agent.ExplorationRover;
import mars.mission.ExplorationMission;

public class RoverBreakdown extends Emergency {
  ExplorationMission mission;
  ExplorationRover rover;
  double required_reapair_equip;
  Storage storage;

  public RoverBreakdown(String emergencyType, String location, String status, ExplorationMission mission,
    double required_reapair_equip,Storage storage) {
    super(emergencyType, location, "unresolved");
    this.mission = mission;
    rover= this.mission.getVehicle();   
    rover.setAvailable(false);
    this.mission.fail("rover broke down");
    this.required_reapair_equip=required_reapair_equip;
    this.storage=storage;
}

 @Override
 public List<Agent> callingAgents(List<Agent> agents) {
     int h=2;int r=1;                                //at most 2 humans and 1 robots
      List<Agent>avaiableResponders=new ArrayList<>(); //at least 1 human and 1 robot
      
        for (Agent responder : agents) {
        if(responder.canHandleEmergency(getEmergencyType())&&responder.isAvailable()){  //waiting the missions part
          
          if(responder.isHuman() && h>0) 
          {
            avaiableResponders.add(responder);
            h--;}
          if(!responder.isHuman() && r>0)
            {
             avaiableResponders.add(responder); 
             r--;
            }
        }
      }
      if(r!=0 || h>1){
        //System.out.println("No enough available agents");
        return new ArrayList<>();
      }
      
      return avaiableResponders;
 }
  
 private void repair(){
  Resource repair_equip=this.storage.getResource("spare parts");
  if (repair_equip.getQuantity()<required_reapair_equip) {
    throw new IllegalArgumentException("No enough spare parts");
  }
  repair_equip.consume(required_reapair_equip);
  rover.setLocation("In laboratory");
  rover.setAvailable(true); 
}
 
 
 @Override 
    public void resolvingEmergency(List<Agent> Responders){
    List<Agent> availableResponders =callingAgents(Responders);
     if(!availableResponders.isEmpty()){
     for(Agent responder :availableResponders){
      responder.setAvailable(false);                //wanna change it to be more protected
      }
      repair();
      freeAgents(availableResponders);
      setStatus("resolved");
    }
    else{
        setStatus("unresolved");
    
        throw new IllegalArgumentException("No enogh responders");
    }}
   
    }
