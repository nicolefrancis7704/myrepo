/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mars.colony;
import mars.agent.Agent;
import java.util.ArrayList;
import java.util.List;

public abstract class Colony {
 private List <Agent> agents= new ArrayList<>();

 public Colony(List<Agent> agents) {
    this.agents = agents;
 }  
    
    
    
    
    







 
}
