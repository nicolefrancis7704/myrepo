package mars_project.Environment;

public class Environment {
    private String type;
    private int elapsedTime;
    public Environment(String type) {
        setType(type);
        this.elapsedTime = 0;
    }
    public String getType() {return type;}

    public void setType(String type) {
        if (type == null || type.trim().isEmpty()) {
            throw new IllegalArgumentException("Environment type cannot be empty.");
        }
        this.type = type.trim();
    }
    // Called once for every simulation time unit.
    // A simple predictable cycle makes environmental changes easy to test.
    public void advanceTime() {
        elapsedTime++;
        if (elapsedTime % 10 == 0) {
            type = "Communication Disruption";
        } else if (elapsedTime % 5 == 0) {
            type = "Dust Storm";
        } else {
            type = "Normal condition";
        }
    }
    public int getElapsedTime() {   return elapsedTime;}

    public boolean isDustStorm() {
        return "dust storm".equalsIgnoreCase(type);
    }

    public boolean isCommunicationDisrupted() {
        return "Communication Disruption".equalsIgnoreCase(type);
    }

    public boolean isNormalCondition() {
        return "Normal condition".equalsIgnoreCase(type);
    }
}
