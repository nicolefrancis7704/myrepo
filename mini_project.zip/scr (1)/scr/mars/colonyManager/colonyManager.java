package mars.colonyManager;

import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Habitats;
import mars.resourcesAndfacilities.Resource;

public class colonyManager {

    private Facilities[] facilities;
    // ------------ Constructor ------------
    public colonyManager(Facilities[] facilities) {
        if (facilities == null) {
            throw new IllegalArgumentException("Facilities array cannot be null.");
        }
        this.facilities = facilities.clone();
        for (Facilities facilitie : this.facilities) {
            if (facilitie == null) {
                throw new IllegalArgumentException("Facility cannot be null.");
            }
        }
        checkResourceUnits();
    }
    // ------------ Check Resource Units ------------
    private void checkResourceUnits() {
        for (int i = 0; i < facilities.length; i++) {
            for (int j = 0; j < facilities[i].resources.length; j++) {
                Resource current = facilities[i].resources[j];
                if (current == null) {
                    continue;
                }
                for (int k = 0; k <= i; k++) {
                    int limit = (k == i) ? j : facilities[k].resources.length;
                    for (int m = 0; m < limit; m++) {
                        Resource previous = facilities[k].resources[m];
                        if (previous != null
                                && previous.getResourceType().equalsIgnoreCase(
                                        current.getResourceType())) {
                            if (!previous.getUnit().equalsIgnoreCase(
                                    current.getUnit())) {
                                throw new IllegalArgumentException(
                                        "Same resource must use the same unit."
                                );
                            }
                        }
                    }
                }
            }
        }
    }


    // ------------ Colony Resource Total ------------

    public double getTotalResourceQuantity(String resourceType) {
        if (resourceType == null || resourceType.trim().isEmpty()) {
            return 0;
        }
        double total = 0;
        for (Facilities facilitie : facilities) {
            if (!facilitie.isOperational()) {
                continue;
            }
            Resource resource = facilitie.getResource(resourceType);
            if (resource != null) {
                total += resource.getQuantity();
            }
        }
        return total;
    }


    // ------------ Allocate Resources ------------
    public String allocateResource(String resourceType, double amount) {
        if (resourceType == null|| resourceType.trim().isEmpty()|| !Double.isFinite(amount) || amount <= 0) {
            return "INVALID_AMOUNT_OR_RESOURCE";
        }

        // Step 1: Check total available quantity
        double total = getTotalResourceQuantity(resourceType);
        if (total < amount) {
            return "INSUFFICIENT_RESOURCE";
        }
        // Step 2: Plan how much to take from each facility
        double[] allocations = new double[facilities.length];
        Resource[] sourceResources = new Resource[facilities.length];
        double remaining = amount;
        for (int i = 0; i < facilities.length; i++) {
            if (!facilities[i].isOperational()) {
                continue;
            }
            Resource resource =facilities[i].getResource(resourceType);
            if (resource == null) {
                continue;
            }
            double available = resource.getQuantity();
            if (available <= 0) {
                continue;
            }
            double taken = Math.min(available, remaining);
            allocations[i] = taken;
            sourceResources[i] = resource;
            remaining -= taken;
            if (remaining <= 0) {
                break;
            }
        }
        if (remaining > 0) {
            return "INSUFFICIENT_RESOURCE";
        }
       // Step 3: Consume the planned quantities
        for (int i = 0; i < facilities.length; i++) {
            if (allocations[i] <= 0) {
                continue;
            }
            boolean consumed =
                    sourceResources[i].consume(allocations[i]);
            if (!consumed) {
                // Rollback: return previously consumed quantities
                for (int j = 0; j < i; j++) {
                    if (allocations[j] > 0) {
                        sourceResources[j].addQuantity(allocations[j]);
                    }
                }
                return "ALLOCATION_FAILED";
            }
        }
        return "SUCCESS";
    }
    // ------------ Local Oxygen Emergency ------------

    public boolean handleOxygenLeak(
            Habitats affectedHabitat, double amount) {
        if (affectedHabitat == null
                || !Double.isFinite(amount)
                || amount <= 0) {
            return false;
        }

        // Make sure this Habitat belongs to this Colony

        boolean belongsToColony = false;
        for (Facilities facilitie : facilities) {
            if (facilitie == affectedHabitat) {
                belongsToColony = true;
                break;
            }
        }
        if (!belongsToColony) {
            return false;
        }
        return affectedHabitat.consumeOxogen(amount);
    }


    // ------------ Colony Status Report ------------

    public String generateStatusReport() {

        StringBuilder report = new StringBuilder();
        int operationalCount = 0;
        report.append("========== COLONY STATUS REPORT ==========\n");
        // Facilities status

        report.append("\nFacilities:\n");
        for (Facilities facilitie : facilities) {
            report.append("- ").append(facilitie.getName()).append(" : ");
            if (facilitie.isOperational()) {
                report.append("Operational\n");
                operationalCount++;
            } else {
                report.append("Not Operational\n");
            }
        }
        report.append("\nOperational Facilities: ")
                .append(operationalCount)
                .append(" / ")
                .append(facilities.length)
                .append("\n");


        // Resource totals
        report.append("\nColony Resource Totals:\n");
        boolean foundResource = false;
        for (int i = 0; i < facilities.length; i++) {
            for (int j = 0; j < facilities[i].resources.length; j++) {
                Resource resource = facilities[i].resources[j];
                if (resource == null) {
                    continue;
                }
                String type = resource.getResourceType();
                if (!isFirstOccurrence(type, i, j)) {
                    continue;
                }
                double total = getTotalResourceQuantity(type);
                report.append("- ")
                        .append(type)
                        .append(": ")
                        .append(total)
                        .append(" ")
                        .append(resource.getUnit())
                        .append("\n");
                foundResource = true;
            }
        }
        if (!foundResource) {
            report.append("No resources available.\n");
        }

        report.append("\n===========================================\n");
        return report.toString();
    }


    // ------------ Check First Occurrence ------------

    private boolean isFirstOccurrence(
            String resourceType, int facilityIndex, int resourceIndex) {
        for (int i = 0; i <= facilityIndex; i++) {
            int limit = (i == facilityIndex)
                    ? resourceIndex
                    : facilities[i].resources.length;

            for (int j = 0; j < limit; j++) {
                Resource previous = facilities[i].resources[j];
                if (previous != null
                        && previous.getResourceType().equalsIgnoreCase(
                                resourceType)) {
                    return false;
                }
            }
        }
        return true;
    }

    public void refundResource(String type, double amount) {
        for (Facilities f : facilities) {
            if (!f.isOperational()) continue;
            Resource r = f.getResource(type);
            if (r != null) {
                r.addQuantity(amount);
                return;
            }
        }
    }
    
    // Consume a resource across operational facilities.
    // Returns false if the colony does not have enough of that resource.
    public boolean consumeResource(String resourceType, double amount) {
        if (resourceType == null || resourceType.trim().isEmpty()
                || !Double.isFinite(amount) || amount <= 0) {
            return false;
        }

        if (getTotalResourceQuantity(resourceType) < amount) {
            return false;
        }

        double remaining = amount;
        for (Facilities facility : facilities) {
            if (!facility.isOperational()) {
                continue;
            }

            Resource resource = facility.getResource(resourceType);
            if (resource == null || resource.getQuantity() <= 0) {
                continue;
            }

            double taken = Math.min(resource.getQuantity(), remaining);
            if (!resource.consume(taken)) {
                return false;
            }
            remaining -= taken;

            if (remaining <= 0) {
                return true;
            }
        }
        return remaining <= 0;
    }

    // ------------ Get Facilities ------------

    public Facilities[] getFacilities() {
        return facilities.clone();
    }
}