/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mars.agent;


/**
 *
 * @author LENOVO
 */
public abstract class Robot extends Agent{
    private boolean damaged;
    private int batteryLevel;
    public Robot(String id, String name, String location, boolean avaiable, int health, boolean damaged,
            int batteryLevel) {
        super(id, name, location, avaiable, health);
        this.damaged = damaged;
        this.batteryLevel = batteryLevel;
    }
    
    public int getBatteryLevel(){return batteryLevel;}
    public boolean isDamaged(){return damaged;}
    @Override
    public boolean isAvailable() {return super.isAvailable()&& !damaged && batteryLevel >0;}
    
    public void setBatteryLevel(int batteryLevel){
        if (batteryLevel<0 || batteryLevel >100){
            throw new IllegalArgumentException ("The battery level should be between 0 and 100");
        }
        this.batteryLevel=batteryLevel;
    }
    public void setDamaged(boolean damaged){this.damaged=damaged;}
    public void consumeBattery(int amount) {
        if (amount < 0 || amount > batteryLevel) {
            throw new IllegalArgumentException("Invalid battery consumption.");
        }
        batteryLevel -= amount;
    }
   @Override
    public boolean isHuman() {
        return false;
    }
  @Override 
    public boolean isRobot(){return true;};
  @Override  
    public boolean worksOnSurface(){return true;};
  @Override   
    public boolean needsCommunication(){return true;};



}

