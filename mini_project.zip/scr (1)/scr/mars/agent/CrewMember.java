/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mars.agent;
import java.util.HashSet;
import java.util.Set;
/**
 *
 * @author LENOVO
 */
public abstract class CrewMember extends Agent {
    private Set<String> skills;
    private int fatigue;

    public CrewMember(String id, String name, String location, boolean avaiable, int health, Set<String> skills,
            int fatigue) {
        super(id, name, location, avaiable, health);
        this.skills = skills;
        this.fatigue = fatigue;
    }
    
    public Set<String> getSkills(){return new HashSet<>(skills);}
    public int getFatigue(){return fatigue;}

    @Override
    public boolean isAvailable() {return super.isAvailable() && fatigue < 100;}
    
    public void increaseFatigue(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount cannot be negative.");
        }
        fatigue = Math.min(100, fatigue + amount);
    }
    
    public void decreaseFatigue(int amount){
        if (amount<0){
            throw new IllegalArgumentException();
        } 
        fatigue=Math.min(100, fatigue-amount);
    }
    
    public void increaseHealth(int amount){
        if (amount<0){
            throw new IllegalArgumentException();
        } 
        setHealth(getHealth()+amount);
    }
    public boolean hasSkill(String skill){
        return skill == null || skill.isEmpty()||skills.contains(skill);
    }
   @Override
    public boolean isHuman() {
        return true;
    }     
  @Override 
    public boolean isRobot(){return false;};
  @Override  
    public boolean worksOnSurface(){return false;};
  @Override   
    public boolean needsCommunication(){return false;};



}
