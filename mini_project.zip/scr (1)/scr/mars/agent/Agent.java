/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mars.agent;

public abstract class Agent {
    private final String id;
    private String name;
    private String location;
    private boolean available;
    private int health;

    public Agent(String id, String name, String location, boolean available, int health) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.available = available;
        this.health = health;
    }

    public void setAvailable(boolean available) { this.available = available; }
    public boolean isAvailable() { return available && isUsable(); }
    public boolean isUsable() { return health > 0; }

    public String getName() { return name; }
    public String getId() { return id; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public int getHealth() { return health; }

    public void setHealth(int health) {
        if (health < 0 || health > 100) {
            throw new IllegalArgumentException("Health should be between 0 and 100");
        }
        this.health = health;
    }

    public abstract boolean isRobot();
    public abstract boolean worksOnSurface();
    public abstract boolean needsCommunication();
    public abstract boolean isHuman();
    public abstract boolean canPerform(String missionType, String requiredSkill);
    public abstract boolean canHandleEmergency(String emergencyType);
    public abstract void performDuty();
}