/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mars.agent;

import java.util.Set;

/**
 *
 * @author LENOVO
 */
public class Engineer extends CrewMember {
    
    public Engineer(String id, String name, String location, boolean avaiable, int health, Set<String> skills,
            int fatigue) {
        super(id, name, location, avaiable, health, skills, fatigue);
    }
    
    @Override
    public boolean canPerform(String missionType , String requiredSkill){
        return "REPAIR".equalsIgnoreCase(missionType)&&hasSkill(requiredSkill);
    }
    
    @Override
    public boolean canHandleEmergency(String emergencyType) {
        return "OXYGEN_LEAK".equalsIgnoreCase(emergencyType)
                ||"ROVER_BREAKDOWN".equalsIgnoreCase(emergencyType)
                ||"FIRE".equalsIgnoreCase(emergencyType);
    }
    @Override
    public void performDuty() {
        System.out.println(getName() + " is repairing equipment.");
    }
}
