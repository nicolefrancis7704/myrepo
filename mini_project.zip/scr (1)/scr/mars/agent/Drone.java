/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mars.agent;

/**
 *
 * @author LENOVO
 */
public class Drone extends Robot {
   
     public Drone(String id, String name, String location, boolean avaiable, int health, boolean damaged,
             int batteryLevel) {
         super(id, name, location, avaiable, health, damaged, batteryLevel);
         
     }
    @Override
    public boolean canPerform(String missionType , String requiredSkill){
        return ("EXPLORATION".equalsIgnoreCase(missionType)||"RECONNAISSANCE".equalsIgnoreCase(missionType))
                &&getBatteryLevel()>0;
    }
    @Override
    public boolean canHandleEmergency(String emergencyType) {
        return false;
    }
    @Override
    public void performDuty() {
        System.out.println(getName() + " is performing aerial reconnaissance.");
    }
    
}
