package mars.mission;
import java.util.*;
import mars.agent.Agent;
import mars.agent.Robot;
import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Resource;
import mars.Environment.Environment;
import mars.colonyManager.colonyManager; 

public class MissionManager {
    private Mission activeMission;
    private List<Mission> missions = new ArrayList<>();
    private List<String> availableEquipment = new ArrayList<>();
    private colonyManager colony;
    private Environment environment;

    public MissionManager(){}
    
    public MissionManager(colonyManager colony, Environment environment) {
        this.colony = colony;
        this.environment = environment;
    }

    public void addEquipment(String item) { 
        availableEquipment.add(item); 
    }
    public void breakEquipment(String item) { 
        availableEquipment.remove(item); 
    }

    private String findRejectionReason(Mission m, List<Agent> agents) {
        if (activeMission != null) {
            return "Another mission is already active.";
        }
        if (agents == null || agents.isEmpty()) {
            return "No agents assigned.";
        }
        for (Agent a : agents) {
            if (a == null || !a.isAvailable()) {
                return "An agent is unavailable.";
            }
        }
        String reason = m.checkAgents(agents);
        if (reason == null) {
            reason = m.checkFacilities();
        }
        if (reason == null) {
            reason = m.checkEnvironment(agents, environment);
        }
        if (reason != null) {
            return reason;
        }
        for (String item : m.getRequiredEquipment()) {
            if (!availableEquipment.contains(item)) {
                return "Missing equipment: " + item;
            }
        }
        for (Map.Entry<String, Double> e : m.getRequiredResources().entrySet()) {
            double have = colony.getTotalResourceQuantity(e.getKey());
            if (have < e.getValue())
                return "Insufficient " + e.getKey() + " (need " + e.getValue() + ", have " + have + ")";
        }
        return null;
    }
    public boolean submitMission(Mission m, List<Agent> agents) {
        if (m == null) {
            return false;
        }
        missions.add(m);
        String reason = findRejectionReason(m, agents);
        if (reason != null) {
            m.fail(reason);
            return false;
        }
        List<String> taken = new ArrayList<>();
        for (Map.Entry<String, Double> e : m.getRequiredResources().entrySet()) {
            String result = colony.allocateResource(e.getKey(), e.getValue());
            if (!result.equals("SUCCESS")) {
                for (String t : taken) {
                    colony.refundResource(t, m.getRequiredResources().get(t));
                }
                m.fail("Resource allocation failed: " + e.getKey());
                return false;
            }
            taken.add(e.getKey());
        }
        m.assign(agents);
        activeMission = m;
        return true;
    }
    public void advanceTime() {
        if (activeMission == null) {
            return;
        }
        for (String item : activeMission.getRequiredEquipment()) {
            if (!availableEquipment.contains(item)) {
                activeMission.fail("Equipment failure: " + item);
            }
        }
        if (activeMission.getStatus() == MissionStatus.ASSIGNED) {
            activeMission.start(environment);
        } 
        else if (activeMission.getStatus() == MissionStatus.IN_PROGRESS) {
            activeMission.advanceTime(environment);
        }
        MissionStatus s = activeMission.getStatus();
        if (s == MissionStatus.COMPLETED || s == MissionStatus.FAILED) {
            activeMission = null;
        }
    }
    public boolean isInActiveMission(Agent a) {
        return activeMission != null && activeMission.getAssignedAgents().contains(a);
    }
    public List<Agent> findResponders(List<Agent> allAgents, String emergencyType) {
        List<Agent> result = new ArrayList<>();
        for (Agent a : allAgents) {
            if (a.isAvailable() && !isInActiveMission(a) && a.canHandleEmergency(emergencyType)) {
                result.add(a);
            }
        }
        return result;
    }
    public boolean hasActiveMission() {
        return activeMission != null; 
    }
    public Mission getActiveMission() {
        return activeMission; 
    }
    public List<Mission> getMissions() {
        return missions; 
    }
}