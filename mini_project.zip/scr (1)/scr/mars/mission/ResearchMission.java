package mars.mission;

import mars.resourcesAndfacilities.Facilities;

public class ResearchMission extends Mission {
    public ResearchMission(String id, int duration, String skill, Facilities lab) {
        super(id, "RESEARCH", duration, skill, 1, 0);
        targetFacilities.add(lab);
        requiredEquipment.add("Scientific Equipment");
        requiredResources.put("Battery Power", 3.0);
    }
    @Override
    public String checkFacilities() {
        if (targetFacilities.isEmpty()) {
            return "A laboratory is required.";
        }
        return super.checkFacilities();
    }
}