package mars.mission;
import java.util.List;
import mars.agent.Agent;
import mars.agent.Robot;
import mars.agent.ExplorationRover;
//import mars.resourcesAndfacilities.Facilities;
//import mars.resourcesAndfacilities.Resource;

public class ExplorationMission extends Mission {
    private static final int BATTERY_PER_UNIT = 5;
    private ExplorationRover vehicle;
    private int requiredBattery;
    private String region;

    public ExplorationMission(String id, int duration, ExplorationRover vehicle,String skill, int requiredBattery, String region) {
        super(id, "EXPLORATION", duration, skill, 1, 1);
        this.vehicle = vehicle;
        this.requiredBattery = requiredBattery;
        this.region = region;
        requiredEquipment.add("Exploration Kit");
    }
    
    public ExplorationRover getVehicle() {
    return vehicle;
    }

    public String getRegion() {
        return region; 
    }
    @Override
    public String checkAgents(List<Agent> agents) {
        if (vehicle == null || !agents.contains(vehicle)) {
            return "A vehicle is required.";
        }
        if (!vehicle.canPerform("EXPLORATION", null)) {
            return "Vehicle cannot perform exploration.";
        }
        int needed = Math.max(requiredBattery, getDuration() * BATTERY_PER_UNIT);
        if (vehicle.getBatteryLevel() < needed)
            return "Insufficient battery: need " + needed + ", have " + vehicle.getBatteryLevel() + ".";
        return super.checkAgents(agents);
    }
    @Override
    protected void onTick() {
        if (vehicle.getBatteryLevel() < BATTERY_PER_UNIT) {
            fail("Vehicle battery is too low to continue.");
            return;
        }
        vehicle.consumeBattery(BATTERY_PER_UNIT);
    }
}