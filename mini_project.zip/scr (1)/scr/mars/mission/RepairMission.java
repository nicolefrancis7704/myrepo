package mars.mission;
public class RepairMission extends Mission {
    public RepairMission(String id, int duration, String skill) {
        super(id, "REPAIR", duration, skill, 1, 1);   // Engineer + Repair Robot
        requiredResources.put("Spare Parts", 2.0);
        requiredResources.put("Battery Power", 5.0);
    }
}