package mars.mission;

import java.util.ArrayList;
import java.util.HashSet;//We want to identify the agents who are currently working on a mission 
                          //without accidentally counting the same agent twice.
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import mars.agent.Agent;
import mars.Environment.Environment;
import mars.agent.CrewMember;
import mars.colonyManager.colonyManager;
import mars.agent.Robot;

public class Simulation {
    private MissionManager missionManager;//when time advances, we need to tell the MissionManager
                                           //to advance the active mission.
    private Environment environment;
    private colonyManager colony;
    private List<Agent> agents; //This is a list containing all the agents participating in the simulation.
    // Simulation clock
    private int currentTime;
    // Stores events according to their scheduled time
    private final TreeMap<Integer, List<Runnable>> schedule  =new TreeMap<>();
    public Simulation() {
        this(null, new Environment("Normal condition")); //Calls the second constructor
    }
    public Simulation(colonyManager colony, Environment environment) {
        if (environment == null) {
            throw new IllegalArgumentException(
                    "Environment cannot be null.");
        }
        this.colony = colony;
        this.environment = environment;
        this.missionManager = new MissionManager(colony, environment);//needs those objects to validate missions and advance them
        this.agents = new ArrayList<>();
        this.currentTime = 0;
    }
    public int getCurrentTime() {return currentTime;}
    public Environment getEnvironment() {return environment;}
    public MissionManager getMissionManager() {return missionManager;}
    public List<Agent> getAgents() {return new ArrayList<>(agents);}//it returns a copy.
    public void addAgent(Agent agent) {
        if (agent == null) {
            throw new IllegalArgumentException(
                    "Agent cannot be null.");
        }
        if (!agents.contains(agent)) {//If the agent is NOT already in the list."
            agents.add(agent);
        }
    }
    // Schedule an event at a specific future time.
    public void schedule(int atTime, Runnable event) {
        if (atTime <= currentTime) {
            throw new IllegalArgumentException("Event must be scheduled in the future.");
        }
        if (event == null) {
            throw new IllegalArgumentException("Event cannot be null.");
        }
        schedule.computeIfAbsent(atTime,k -> new ArrayList<>()).add(event); //IF multiple events happen at the same time
    }
    // Advance the simulation by multiple time units.
    public void advanceTime(int units) {
        if (units < 0) {
            throw new IllegalArgumentException("Time units cannot be negative.");
        }
        for (int i = 0; i < units; i++) {
            step();
        }
    }
    // One complete simulation time unit.
    private void step() {
        // 1. Advance the simulation clock.
        currentTime++;
        int t = currentTime;
        // 2. Execute events scheduled for this time.
        List<Runnable> events = schedule.remove(t);
        if (events != null) {
            for (Runnable event : events) {
                event.run();
            }
        }
        // 3. Identify the active mission and busy agents.
        Mission mission = missionManager.getActiveMission();
        Set<Agent> busy = new HashSet<>();//Creates an empty set to store agents currently working on a mission.
        if (mission != null) {
            busy.addAll(mission.getAssignedAgents());//Returns the agents assigned to that mission.
        }
        // 4. Advance mission progress.
        missionManager.advanceTime();
        // 5. Update fatigue and battery levels.
        for (Agent agent : agents) {//This loop visits every agent in our simulation.
            if (agent instanceof CrewMember) {//instanceof checks the actual type of an object.
                CrewMember crew = (CrewMember) agent;//We convert the reference from Agent to CrewMember
                                                       //so that we can access CrewMember-specific methods.
                if (busy.contains(agent)) {
                    // Working crew members become tired.
                    crew.increaseFatigue(5);
                } else {
                    // Resting crew members recover.
                    crew.decreaseFatigue(2);
                }
            }
            else if (agent instanceof Robot && busy.contains(agent)) {
                Robot robot = (Robot) agent;
                // ExplorationMission already consumes 5 battery
                // units inside its onTick() method.
                boolean exploration =mission != null &&"EXPLORATION".equalsIgnoreCase(mission.getMissionType());
                if (!exploration && robot.getBatteryLevel() > 0) {
                    robot.consumeBattery(1);
                }
            }
        }
        // 6. Consume colony resources.
        if (colony != null) {
            colony.consumeResource("Oxygen", 1.0);
            colony.consumeResource("Water", 1.0);
            colony.consumeResource("Food", 10.0);
        }
        // 7. Advance environmental conditions.
        environment.advanceTime();
        // 8. Print simulation status.
        if (mission != null) {
            System.out.println("[t=" + t + "] "+ mission.getId()+ " -> " + mission.getStatus()
                    + " (" + mission.getTimePassed()+ "/" + mission.getDuration() + ")"
                    + (mission.getFailureReason() != null? " reason: " + mission.getFailureReason(): ""));
        } else {
            System.out.println("[t=" + t + "] no active mission");
        }
        System.out.println("Environment: " + environment.getType());
    }
}