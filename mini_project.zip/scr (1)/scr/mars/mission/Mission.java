package mars.mission;
import java.util.*;
import mars.agent.Agent;
import mars.agent.Robot;
import mars.resourcesAndfacilities.Facilities;
import mars.resourcesAndfacilities.Resource;
import mars.Environment.Environment; 

public abstract class Mission {
    private String id;
    private String type;
    private int duration;
    private int timePassed = 0;
    private MissionStatus status = MissionStatus.PENDING;
    private String failureReason;
    private String requiredSkill;
    private int minHumans;
    private int minRobots;
    private List<Agent> assignedAgents = new ArrayList<>();
    protected List<Facilities> targetFacilities = new ArrayList<>();
    protected Map<String, Double> requiredResources = new HashMap<>();
    protected List<String> requiredEquipment = new ArrayList<>();

    public Mission(String id, String type, int duration, String requiredSkill,
                   int minHumans, int minRobots) {
        this.id = id;
        this.type = type;
        this.duration = duration;
        this.requiredSkill = requiredSkill;
        this.minHumans = minHumans;
        this.minRobots = minRobots;
    }
    
    public String getId() { 
        return id; 
    }
    public String getMissionType() {
        return type; 
    }
    public int getDuration() { 
        return duration; 
    }
    public int getTimePassed() {
        return timePassed; 
    }
    public MissionStatus getStatus() {
        return status; 
    }
    public String getFailureReason() {
        return failureReason; 
    }
    public List<Agent> getAssignedAgents() {
        return assignedAgents; 
    }
    public List<Facilities> getTargetFacilities() {
        return targetFacilities; 
    }
    public Map<String, Double> getRequiredResources() {
        return requiredResources; 
    }
    public List<String> getRequiredEquipment() {
        return requiredEquipment; 
    }
    public String checkAgents(List<Agent> agents) {
        int numHumans = 0;
        int numRobots = 0;
        for (Agent a : agents) {
            if (a == null) {
                return "Agent list contains a null agent.";
            }
            if (a.canPerform(type, requiredSkill)) {
                if (a.isRobot()) {
                    numRobots++;
                } 
                else {
                    numHumans++;
                }
            }
        }
        if (numHumans < minHumans) {
            return "Need at least " + minHumans + " capable human(s) for " + type + ".";
        }
        if (numRobots < minRobots) {
            return "Need at least " + minRobots + " capable robot(s) for " + type + ".";
        }
        return null;
    }
    public String checkFacilities() {
        for (Facilities f : targetFacilities) {
            if (f == null || !f.isOperational()) {
                return "Target facility is not operational.";
            }
        }
        return null;
    }
    public String checkEnvironment(List<Agent> agents, Environment env) {
        for (Agent a : agents) {
            if (env.isDustStorm() && a.worksOnSurface())
                return "Dust storm: " + a.getName() + " cannot work on the surface.";
            if (env.isCommunicationDisrupted() && a.needsCommunication())
                return "Communication disrupted: " + a.getName() + " cannot be controlled.";
        }
        return null;
    }
    public String checkAgentsStillOk() {
        for (Agent a : assignedAgents) {
            if (!a.isUsable()) {
                return a.getName() + " is no longer usable.";
            }
        }
        return null;
    }

    protected void onTick() { }

    private String findProblem(Environment env) {
        String problem = checkAgentsStillOk();
        if (problem == null) {
            problem = checkEnvironment(assignedAgents, env);
        }
        if (problem == null) {
            problem = checkFacilities();
        }
        return problem;
    }
    public void assign(List<Agent> agents) {
        assignedAgents = new ArrayList<>(agents);
        for (Agent a : assignedAgents) {
            a.setAvailable(false);
        }
        status = MissionStatus.ASSIGNED;
    }
    public void start(Environment env) {
        if (status != MissionStatus.ASSIGNED) {
            return;
        }
        String problem = findProblem(env);
        if (problem != null) { 
            fail(problem); 
            return; 
        }
        status = MissionStatus.IN_PROGRESS;
    }
    public void advanceTime(Environment env) {
        if (status != MissionStatus.IN_PROGRESS) {
            return;
        }
        String problem = findProblem(env);
        if (problem != null) { 
            fail(problem); 
            return; 
        }
        timePassed++;
        onTick();
        if (status != MissionStatus.IN_PROGRESS) {
            return;
        }
        if (timePassed >= duration) {
            complete();
        }
    }
    public void complete() {
        if (status == MissionStatus.IN_PROGRESS) {
            status = MissionStatus.COMPLETED;
            releaseAgents();
        }
    }
    public void fail(String reason) {
        if (status == MissionStatus.COMPLETED || status == MissionStatus.FAILED) {
            return;
        }
        status = MissionStatus.FAILED;
        failureReason = reason;
        releaseAgents();
    }
    private void releaseAgents() {
        for (Agent a : assignedAgents) {
            a.setAvailable(true);
        }
    }
}