package mars.mission;

import java.util.List;
import mars.agent.Agent;
import mars.Environment.Environment;
import mars.agent.Robot;

public class RescueMission extends Mission {
    private String emergencyType;
    private Robot vehicle;
    private int minPersonnel;

    public RescueMission(String id, int duration, String emergencyType,Robot vehicle, int minPersonnel) {
        super(id, "RESCUE", duration, null, minPersonnel, 1);
        this.emergencyType = emergencyType;
        this.vehicle = vehicle;
        this.minPersonnel = minPersonnel;
    }

    @Override
    public String checkAgents(List<Agent> agents) {
        if (vehicle == null || !agents.contains(vehicle)) {
            return "A rescue vehicle is required.";
        }
        if (!vehicle.canPerform("EXPLORATION", null)) {
            return "Vehicle is not suitable for rescue.";
        }
        int personnel = 0;
        for (Agent a : agents) {
            if (a != vehicle && !a.isRobot() && a.canHandleEmergency(emergencyType)) 
                personnel++;
        }
        if (personnel < minPersonnel)
            return "Need at least " + minPersonnel + " personnel able to handle " + emergencyType + ".";
        return null;
    }
    @Override
    public String checkEnvironment(List<Agent> agents, Environment env) {
        if (env.isCommunicationDisrupted()) {
            return "Communication disrupted.";
        }
        return super.checkEnvironment(agents, env);
    }
}